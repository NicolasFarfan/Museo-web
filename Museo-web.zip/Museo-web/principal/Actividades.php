<?php include ('cabecera.php') ?>
<div> 
    <br>
    <label for="aqui">Reservar cita guiada: </label>
    <a href="Admin/InicioSesion.php"><input type="button" value="Aqui! "></a>
</div>
<br>
<h3 style="padding-left: 20px ;">Actividades de la Semana</h3>
<br>
<div style="background-color: #d5dbdb ; border-radius: 30px;">
    <div style="display: flex;">
        <img src="src/Exposiciones/realidad virtual.webp" alt="DomoVisual"  width="300px" style="padding-right:1m; padding-top:20px; padding-left: 20px; border-radius: 35px; ">
        <br>
        <div style="padding-left: 100px;padding-top: 10px;" >
            <h4>Realidad virtual</h4>
            <p>Sumerguete en una travecia 3D por todo la era Mesopotamica.</p>
            <p>Modalidad: Presecial</p>
            <div style="display: inline-flex;"> 
                <p>Horarios:</p>
                <p> 8:00hs / 9:00hsa / 16:00hs / 17:00h</p>
            </div>
        </div>
    </div>
    <br>
</div>
<br><br>
<div style="background-color: #d5dbdb ; border-radius: 30px;">
    <div style="display: flex;">
        <img src="src/Exposiciones/acyividad1.jpeg" alt="" width="300x" style="padding-right:1m; padding-top:20px; padding-left: 20px; border-radius: 35px;">
        <br>
        <div style="padding-left: 100px;padding-top: 10px;" >
            <h4>Cursos Educativos</h4>
            <p>Aprende sobre los grandes inventos de nuestro pais.</p>
            <p>Modalidad:Presencial</p>
            <div style="display: inline-flex;"> 
                <p>Horarios:</p>
                <p> 12:00hs / 13:00hsa / 14:00hs / 15:00h</p>
            </div>
        </div>
    </div>
    <br>
</div>
<br><br>
<div style="background-color: #d5dbdb ; border-radius: 30px;">
    <div style="display: flex;">
        <img src="src/Exposiciones/jalowin.jpeg" alt="" width="300x" style="padding-right:1m; padding-top:20px; padding-left: 20px; border-radius: 35px;">
        <br>
        <div style="padding-left: 100px;padding-top: 10px;" >
            <h4>Celebración de Hallowen</h4>
            <p>Cuento de leyendas Urbanas, concurso de dizfraces y más.</p>
            <p>Modalidad:Presencial</p>
            <div style="display: inline-flex;"> 
                <p>Horarios: </p>
                <p> 18:00hs / 19:00hs / 20:00h</p>
            </div>
        </div>
    </div>
    <br>
</div>
<br><br><br>
<?php include ('pie.php') ?>