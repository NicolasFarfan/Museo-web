<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'museoabelito');

if (isset($_POST['guardar'])) {	 
    $Fecha = $_POST['Fecha'];
    $Hora = $_POST['Hora'];
    $Disponible = isset($_POST['Disponible']) ? $_POST['Disponible'] : false;  // Verifica si el campo 'disponible' está en el formulario y si no, lo asigna a false.
    $query = "INSERT INTO Disponibilidad (Fecha, Hora) VALUES ('$Fecha', '$Hora')";
     $result = mysqli_query($conn, $query);
    if ($result) {
            echo "Datos insertados correctamente";
    } else {
            echo "Error al insertar datos: " . mysqli_error($conn);
     }
    } else {
        // Si 'disponible' no es TRUE (o no está marcado), no se ejecuta el insert
        echo "No se puede enviar los datos porque el campo 'disponible' no está activo.";
    }
      header("Location: Reservas.php?mensaje=Resgistro Exitoso");								

?>
