<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'museoabelito');

if (isset($_POST['crear-horario'])) {	
      $Fecha = $_POST['Fecha'];
      $Hora = $_POST['Hora'];	        
      $Disponibilidad = $_POST ['Disponibilidad'] ;               
      $query = "INSERT INTO Disponibilidad(Fecha, Hora, Disponibilidad) VALUES ('$Fecha', '$Hora', '$Disponibilidad')";	// Alta de datos con SQL
      $result = mysqli_query($conn, $query);
      header("Location: Administracion.php?mensaje=Resgistro Exitoso");	
    }									
?>
