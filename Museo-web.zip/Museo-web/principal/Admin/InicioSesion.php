<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'museoabelito');?>

<!doctype html>
<html lang="en">
    <head>
        <title>Iniciar Sesion </title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />
    </head>

    <header style="width: 100%; padding-left: 6px;">
        <nav class="navbar navbar-expand navbar-light bg-light">
            <div class="nav navbar-nav">
                <a class="nav-item nav-link active" href="../../index.php" aria-current="page" style="padding-right: 5px;">Inicio</a>
        </nav>
    </header>

<body>
<br>
    <div class="col-md-8" style="padding-left: 400px; padding-top:70px">
    <form action="Redireccion.php" method="post">
    <div class="card">
        <div class="card-header">Inicio de sesión</div>
        <div class="card-body">
            <div class="mb-3">
                <label for="Correo" class="form-label">Email</label>
                <input type="email" class="form-control" name="Correo" id="Correo" aria-describedby="helpId" placeholder="Ingrese su Correo" required/>
            </div>
            <div class="mb-3">
                <label for="Contraseña" class="form-label">Contraseña</label>
                <input type="password" class="form-control" name="Contraseña" id="Contraseña" aria-describedby="helpId" placeholder="Ingrese su contraseña" required autocomplete="off" />
            </div>
            
            <small id="helpId" class="form-text text-muted">En caso de no tener Usuario debe</small>
                    <a href="Registrarse.php" style="padding-left: 1px;"><small>Registrarse</small></a>
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary" name="guardar">Iniciar sesión</button>
            </div>
        </div>  
    </div>
</form>
    </div>


    <br><br><br>

<!-- Bootstrap JavaScript Libraries -->
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"></script>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"></script>
    </body>
</html>