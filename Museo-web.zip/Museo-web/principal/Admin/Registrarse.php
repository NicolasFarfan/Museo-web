<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'museoabelito');?>

<!doctype html>
<html lang="en">
    <head>
        <title>Registro</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />
    </head>

    <header style="width: 100%; padding-left: 6px;">
        <nav class="navbar navbar-expand navbar-light bg-light">
            <div class="nav navbar-nav">
                <a class="nav-item nav-link active" href="InicioSesion.php" aria-current="page">< volver</a>
        </nav>
    </header>


<body>
    <div class="col-md-8" style="padding-left: 400px; padding-top: 15px;">
            <form action="Reservas.php" method="post">
         <div class="card">
            <div class="card-header">Registro</div>
            <div class="card-body">
            <div class="mb-3">
                    <label for="" class="form-label">Nombre</label>
                    <input type="text" class="form-control" name="Nombre" id="Nombre" aria-describedby="helpId" required autocomplete="off" placeholder="Ingrese un nombre"/>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Email</label>
                    <input type="email" class="form-control" name="Correo" id="Correo" aria-describedby="helpId" placeholder="Ingrese una correo" required/>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" name="Contraseña" id="Contraseña" aria-describedby="helpId" placeholder="Ingrese una contraseña" required/>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Discapacidad</label>
                    <input type="text" class="form-control" name="Discapacidad" id="Discapacidad" aria-describedby="helpId" placeholder="Indique si padece alguna discapacidad" />
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Nacionalidad</label>
                    <input type="text" class="form-control" name="Nacionalidad" id="Nacionalidad" aria-describedby="helpId" placeholder="Ingrese su pais de origen" />
                </div>
                <div class="d-grid gap-2">
                    <input type="submit" name="guardar" value="Registrarse" class="btn btn-primary" >
                </div>
            </div>  
        </div>
    </form>
    </div>

<!-- Bootstrap JavaScript Libraries -->
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"></script>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"></script>
    </body>
</html>