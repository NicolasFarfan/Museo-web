<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'museoabelito');

if (isset($_POST['guardar'])) {	
      $Nombre = $_POST['Nombre'];
      $Correo = $_POST['Correo'];	        
      $Contraseña = $_POST['Contraseña'];
      $Discapacidad = $_POST['Discapacidad'];
      $Nacionalidad = $_POST['Nacionalidad'];                      # Verificacion si se repite el dato de Nombre(para no repetir producto)
      $query = "INSERT INTO usuarios( Nombre, Correo, Contraseña, Discapacidad, Nacionalidad) VALUES ('$Nombre', '$Correo', '$Contraseña', '$Discapacidad', '$Nacionalidad')";	// Alta de datos con SQL
      $result = mysqli_query($conn, $query);
      header("Location: Reservas.php?mensaje=Resgistro Exitoso");
    }									
?>

<!doctype html>
<html lang="en">
    <head>
        <title>Reservas</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />
    </head>

    <body>
    <div style="text-align: center; background-color: #d6eaf8; padding: 20px; border: 1px solid #ccc; border-radius: 10px; width: 80%; margin: 40px auto;"> 
    <h2>Ingrese los siguientes datos:</h2>
    <form action="Subiendo.php" method="POST">
    <div style="display: inline-block;">
        <label for="Fecha">Fecha: </label>
        <select name="Fecha" id="Fecha">
            <option value="">Selecciona una fecha</option>
            <?php 
            $query = "SELECT DISTINCT Fecha FROM disponibilidad WHERE Disponibilidad = 1";
            $result_tasks = mysqli_query($conn, $query);
            while ($row = mysqli_fetch_assoc($result_tasks)) {
                // Mostrar la fecha seleccionada si ya fue seleccionada
                echo '<option value="' . $row['Fecha'] . '"' . (isset($_POST['Fecha']) && $_POST['Fecha'] == $row['Fecha'] ? ' selected' : '') . '>' . $row['Fecha'] . '</option>';
            }
            ?>
        </select>
    </div>

    <div style="display: inline-block;">
        <label for="Hora">Hora: </label>
        <select name="Hora" id="Hora">
            <option value="">Selecciona una hora</option>
            <?php 
                $query = "SELECT DISTINCT Hora FROM disponibilidad WHERE Disponibilidad = 1";
                $result_tasks = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result_tasks)) {
                    // Mostrar las horas disponibles
                    echo '<option value="' . $row['Hora'] . '">' . $row['Hora'] . '</option>';
                }
            ?>
        </select>
    </div>

    <input type="submit" value="Subir" name="subir" id="subir">
    <a href="../../index.php"><input type="button" value="Inicio"></a>
</form>
            
        </div>



        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"
        ></script>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
