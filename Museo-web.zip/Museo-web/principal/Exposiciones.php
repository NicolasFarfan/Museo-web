<?php include ('cabecera.php') ?>
<br><br>
<div style=" display: flex; justify-content: space-between;" >
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:15px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/001.jpeg" alt="exposicion_1" width="275px"></a>
        <center><p>Costura y Pintura</p></center>
    </div>
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/0002.jpeg" alt="exposicion_2" width="280px"></a>
        <center><p>Colección de Hubert</p></center>
    </div>
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/003.jpg" alt="exposicion_2" width="280px"></a>
        <center><p>Colección de Ponce</p></center>
    </div>
</div>

<br>
<div style=" display: flex; justify-content: space-between;">
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/artelatino.jpeg" alt="" width="280px"></a>
        <center><p>Arte Latinoamericano</p></center>
    </div>
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px; padding-top: 40px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/impresio.jpeg" alt="" width="280px"></a>
        <center><p>Impresionalismo</p></center> 
    </div>
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px; padding-top: 40px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/vanguardista.jpg" alt="" height="170px" width="280px" ></a>
        <center><p>Impresionalismo</p></center> 
    </div>
</div>

<br>
<div style=" display: flex; justify-content: space-between;" >
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/004.jpg" alt="exposicion_2" width="280px"></a>
        <center><p>Restos arqueologicos</p></center>
    </div>
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/0055.jpg" alt="exposicion_2" width="280px"></a>
        <center><p>Historia Argentina</p></center>
    </div>
    <div style="background-color: #e5e7e9 ; border-radius: 10px; padding:10px;">
        <a href="Exposicion.php"><img src="src/Exposiciones/006.jpg" alt="exposicion_2" width="280px"></a>
        <center><p>Arte Moderno</p></center>
    </div>


</div>

<br><br>
<?php include ('pie.php') ?>