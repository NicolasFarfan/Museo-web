<?php include ('cabecera.php') ?>
<br><br>
<div style="padding-left: 20px;padding-right: 20px;background-color:lavender; padding-left: 30px;">
        <br>
        <h3>Accesibilidad</h3>
        <p style="padding-right: 500PX;  z-index: 100;">El Museo Abelito trabaja para desarrollar una experiencia inclusiva ofreciendo una atención de calidad al público, basada en el principio del diseño universal,
             a través de una programación educativa que englobe tanto actividades diseñadas para personas con discapacidad como una amplia variedad de actividades integradas que buscan activar la participación, el ejercicio de ciudadanía
            y el acceso a la cultura, potenciando las capacidades de todas las personas.</p>
        <div style="display: flex;">
        <img src="src/infraestructura2.jpg" alt="muestra" width="450px"  style="padding-right:1m; padding-top:10px">
            <div style="padding-left: 100px;">
            <br>
            <li> El Museo posee rampas desde su ingreso y con acceso a todas sus salas.</li>
            <li> Cuenta con ascensor (apertura de puerta 70 cm) para acceder a todos los pisos.</li>
            <li> Sillas de ruedas en Informes para disposición del público.</li>
            <li> Perros guía, ¡bienvenidos! (Ley N°26.858/2013).</li>
            <li> Visitas guiadas para personas ciegas o con baja visión y Recorridos en Lengua de señas Argentina (LSA).</li> 
            <li> Audioguía para personas ciegas o con baja visión: un acercamiento a la colección del Museo a través de trece pistas de audio referidas a grandes obras del museo.</li>
            </div>
        </div>   
    <br><br><br><br><br><br>
</div>
    
    

<?php include ('pie.php') ?>