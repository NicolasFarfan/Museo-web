<?php
session_start();									// PHP llamará a los gestores de almacenamiento de sesiones open y read

													// Conecta con el SERVIDOR WEB LOCAL: localhost - super_user: root - pass: (sin password)
													// Luego con la base de datos en MYSQL formulario, sino muestra el Error de conexión.
$conn = mysqli_connect('localhost', 'root', '', 'museoabelito');

?>
<!doctype html>
<html lang="en">
    <head>
        <title>Museo Abelito</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />
    </head>

    <header style="width: 100%; position: fixed;">
        <a href="principal/Admin/InicioSesion.php"><img src="principal/src/redes/icono-inicio-sesion-o-verificacion-usuario-3d-simbolo-humano-iconos-aplicaciones-ux-ui-movil_716564-372.avif" alt="logo" style="height: 56px; float: right;"></a>
        <nav class="navbar navbar-expand navbar-light bg-light" style="padding-left: 10px;">
    <div class="nav navbar-nav">
        <a class="nav-item nav-link active" href="index.php" aria-current="page">Inicio</a>
        <a class="nav-item nav-link" href="principal/Actividades.php">Actividades</a>
        <a class="nav-item nav-link" href="principal/Exposiciones.php">Exposiciones</a>
        <a class="nav-item nav-link" href="principal/Accesibilidad.php">Accesibilidad</a>
    </div>
    </header>
    <body>
        <div style=" background-image: url(principal/src/museo.jpg); background-size: 100%; color: #ffffff;">
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <h1 style="float: right;">Desde 1956</h1><br><br>
        </div>
<br>
<div style="padding-left: 30px; padding-right: 300px">
<h1>Nuestra Historia</h1>
<div id="historia"></div>
    <p>El Museo Abelito de Buenos Aires, institución pública dependiente del Ministerio de Cultura del Gobierno de la Ciudad de Buenos Aires, fue creado en abril de 1956 por iniciativa de Rafael Squirru, su primer director. 
    Desde sus inicios, el Moderno fue un museo de vanguardia, verdadera casa de los artistas argentinos, y un espacio dedicado a promover las últimas producciones de todas las disciplinas artísticas.
    Hoy, a 68 años de su fundación, el Abelito cuenta con su sede completa en funcionamiento tras la última inauguración del edificio en julio de 2018.</p>
    <p>El Museo Abelito fue inaugurado en diciembre de 1896 en el edificio de las tiendas Bon Marché de la calle Florida,
    hoy Galerías Pacífico. Desde su origen, se planteó como un espacio destinado a albergar arte internacional de todos los períodos históricos,
    y a promover y consolidar un arte argentino por entonces incipiente.</p>
    
    <p>Hacia 1910, en épocas del Centenario de la Revolución de Mayo,
    el Museo ya contaba en su colección con piezas de los maestros Francisco de Goya,
    Joaquín Sorolla y Bastida, Edgar Degas y Pierre-Auguste Renoir.</p>
    <br>
    <div style="display: flex;">
        <div><p>La institución fue trasladada en 1933 a su sede actual: Av. San Juan Domingo Peron 1822. Florencio Varela,
            Buenos Aires, remodelada por el arquitecto Alejandro Bustillo. Durante esos años, se incorporaron destacadas piezas,
            entre ellas, Mujer del mar, de Paul Gauguin, Le Moulin de la Galette, de Vincent van Gogh,
            y Jesús en el huerto de los Olivos, de El Greco.</p>
            <p>Las últimas décadas del siglo XX acogieron a grandes referentes del arte moderno internacional.
            Así, se sumaron obras de Pablo Picasso, Amedeo Modigliani, Marc Chagall, Vassily Kandinsky,
            Paul Klee, Lucio Fontana, Jackson Pollock, Mark Rothko y Henry Moore.</p>
        </div>
        <div>
            <img src="principal/src/Exposiciones/museoviejo.jpeg" alt="" width="300px" style="padding-left:50px;">
        </div>
    </div>
    <p>La historia de la producción local también se narra en las salas del Museo, que exhibe 
    un vasto panorama de arte argentino, con obras de sus mayores representantes como Cándido López,
    Prilidiano Pueyrredón, Emilio Pettoruti, Xul Solar, Raquel Forner, Grete Stern, Antonio Berni,
    Alicia Penalba, Gyula Kosice, Marta Minujín, Antonio Seguí y León Ferrari.
    Además, posee un importante conjunto de arte latinoamericano, que reúne obras de Pedro Figari,
    Joaquín Torres García, Tarsila Do Amaral, Diego Rivera y Jesús Rafael Soto, entre otras.</p>
    
    <p>En sus más de 120 años, el Museo Abelito ha formado una importante colección 
    de más de trece mil piezas de diferentes períodos artísticos, nacionales e internacionales,
    que lo constituye como una de las instituciones culturales más relevantes del continente.</p>
</div>

<?php include ('principal/pie.php')?>